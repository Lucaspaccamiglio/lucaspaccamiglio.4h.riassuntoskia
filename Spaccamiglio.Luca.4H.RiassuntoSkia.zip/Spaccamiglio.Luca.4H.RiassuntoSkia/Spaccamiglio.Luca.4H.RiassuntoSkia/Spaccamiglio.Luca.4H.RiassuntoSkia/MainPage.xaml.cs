﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using SkiaSharp.Views.Forms;
using SkiaSharp;

namespace Spaccamiglio.Luca._4H.RiassuntoSkia
{
    public partial class MainPage : ContentPage
    {
        public int margineSinistro { get; set; } = 100;
        public int marginSopra{ get; set; } = 100;
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnDisegno_Clicked(object sender, EventArgs e)
        {

        }

        private void SKCanvasView_PaintSurface(object sender, SKPaintSurfaceEventArgs e)
        {
            var info = e.Info;
            var canvas = e.Surface.Canvas;
            canvas.Clear();

            int larghezza = info.Rect.Width;//1200
            int altezza = info.Rect.Height;//794

            
        }
        //SKPath AreaDelDisegno()
       // {
       //     SKPath rettangolo = new SKPath();
       //   rettangolo.MoveTo();
       //   return;
       // }
    }
}
